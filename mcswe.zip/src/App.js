import "./styles.css";
import React from "react";

class App extends React.Component {
  constructor(props) {
    super(props);
    this.state = {
      className: "changeClass beforeClick"
    };
    this.onClickHandle = this.onClickHandle.bind(this);
  }

  onClickHandle() {
    this.setState({
      className: "changeClass afterClick"
    });
  }

  render() {
    return (
      <div className="App">
        <div className={this.state.className}>
          <button onClick={this.onClickHandle}>Change Color</button>
        </div>
      </div>
    );
  }
}

export default App;
